<?php

include_once 'checkConnection.php';
session_start();
if(isset($_POST['SignIn'])){
	
	$uname = $_POST['Email1'];
	$password = $_POST['password'];
	if(empty($_POST['Email1']) || empty($_POST['Email1']))
	{
		header("location:loginPage.php?Empty= Please Fill in All the Required fields");
	}
	else
	{
		$sql= "select * from login where username= '".$uname."' AND password = '".$password."' limit 1";
		$result = mysqli_query($conn,$sql);
		if(mysqli_fetch_assoc($result))
		{
			$_SESSION['User'] = $uname; 
			header("location:homePage.php");
		}
		else
		{
			header("location:loginPage.php?Invalid= Please Enter the Correct Student number and Password");
			
		}
	}
	
	

}

/*if(isset($_POST['track'])){
	
	$query = "SELECT `FullName`, `Snumber`,`Problem`,  `TicketStatus` FROM `softwareform` WHERE `Snumber`= '201418090'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$results = mysqli_query($conn,$query);

	if(mysqli_num_rows($results) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			
			
			
			
		}
			
	}}else{
			$Snum = " ";
			$status = " ";
			$FullNames1 = " ";
			$Problem = " ";
	
	//mysqli_free_result($result);
	mysqli_close($conn);

	}*/

?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />

    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>
<body>




<?php

include_once 'checkConnection.php';
if(isset($_POST['SignIn'])){
	
	$uname = $_POST['Email1'];
	$password = $_POST['password'];
	if(empty($_POST['Email1']) || empty($_POST['Email1']))
	{
		header("location:loginPage.php?Empty= Please Fill in All the Required fields");
	}
	else
	{
		$sql= "select * from login where username= '".$uname."' AND password = '".$password."' limit 1";
		$result = mysqli_query($conn,$sql);
		if(mysqli_fetch_assoc($result))
		{
			$_SESSION['User'] = $uname; 
			header("location:homePage.php");
		}
		else
		{
			header("location:loginPage.php?Invalid= Please Enter the Correct Student number and Password");
			
		}
	}
	
	

}


/*if(isset($_POST['track'])){
	
	$query = "SELECT `FullName`, `Snumber`,`Problem`,  `TicketStatus` FROM `softwareform` WHERE `Snumber`= '201418090'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$results = mysqli_query($conn,$query);

	if(mysqli_num_rows($results) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			
			
			
			
		}
			
	}}else{
			$Snum = " ";
			$status = " ";
			$FullNames1 = " ";
			$Problem = " ";
	
	//mysqli_free_result($result);
	mysqli_close($conn);

	}*/

?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />

    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>

<body style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
 
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="100%" height="40">
</a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  

      <ul class="nav navbar-nav navbar-left" style='margin-left: 1%'>
        <li role="presentation" class="active"><a href="track1.php">Home</a></li>

      </ul>
	  
	 
	 
	<ul class="nav navbar-nav navbar-right" style='margin-left: 1%'>
        
		<li role="presentation"><a href="logout.php" name = "logout">LOGOUT <span class="glyphicon glyphicon-off" aria-hidden="true"></span> </a></li>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

</header>



  



 
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">



        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">



<div class = "col-md-12" style='margin-left:30%' align='left'>
	<div class="well" >
	<p class="lead">
	

				 
<a href="track1.php" name = "logout"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="30" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
</svg> </a>
                  

     <h2 class="text-uppercase text-center mb-5">Ticket Details</h2>
<hr/>
	  <?php
$reference =" ";
include_once 'checkConnection.php'; 

 
   

    if(isset($_POST['Search'])){
	$reference = $_POST['reference'];
	$query1 = "SELECT * FROM `softwareform` WHERE `Snumber`= '$reference'";
	$result1 = mysqli_query($conn,$query1);
	$queryResult = mysqli_num_rows($result1 );
	
		if($queryResult > 0){
		    while($row = mysqli_fetch_assoc($result1)){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			$surname = $row['Surname'];
			$email = $row['Email'];
			$numbers =$row['Mobile'];
		}
	}
	}	
	
		$query = "SELECT * FROM `softwareform` WHERE `Snumber`= '$reference'";
	$result = mysqli_query($conn,$query);
	if($result){
		foreach($result as $row){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			$surname = $row['Surname'];
			$email = $row['Email'];
			$numbers =$row['Mobile'];
			$_SESSION['User'] = $reference; 
		}
	}
	3


		


?>


       <form action="" method = "post">
		     <div class="form-group">
            <label for="recipient-name" class="control-label" name="ss"><h4>Status: <span class="label label-warning"><?php echo $status ?></span></h4> </label>
            
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Full Name:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $FullNames1 ?>" readonly>
          </div>
		  
		  <div class="form-group">
            <label for="recipient-name" class="control-label">Surname:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $surname ?>" readonly>
          </div>
		  
		    <div class="form-group">
            <label for="recipient-name" class="control-label">Reference Number:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $Snum ?>" readonly>
          </div>
		  
		            <div class="form-group">
            <label for="recipient-name" class="control-label">Email Address:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $email ?>" readonly>
          </div>
		  
		  <div class="form-group">
            <label for="recipient-name" class="control-label">Phone Numbers:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $numbers ?>" readonly>
          </div>
		  
		  
		  
		          <div class="form-outline mb-4">
                  <label class="form-label" for="Phone">Query:</label>
                  <div class="form-outline">
                  <textarea class="form-control" id="textAreaExample" name="problems" rows="4" required><?php echo $Problem ?></textarea>
                  
                </div>
				<br/>
				

</form>
                <!-- Default checked radio -->

		
	
        </div>
		<br/>
		
        
        <form action="track1.php" method = "post">
			 
				<br/>
				
				<div class="modal-footer"> <button type="submit" name = "Progress" class="btn btn-success btn-block btn-lg gradient-custom-4  text-body">IN Progress</button></div>
				<br/>
				<div class="modal-footer"> <button type="submit" name = "complete" class="btn btn-success btn-block btn-lg  gradient-custom-4 text-body">Complete</button></div>
				
		
        
        </form>
        
		
      </div>
      
    
  </div>

</div>

</body>	


		
           

            


</body>
  