<?php

$host="localhost";
$user="root";
$password="";
$db="Helpdesk";
$conn=mysqli_connect($host,$user,$password,"$db");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}else{
	echo '';
}




?>
