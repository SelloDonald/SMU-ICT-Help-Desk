<?php
include_once 'checkConnection.php';
session_start();
if(isset($_POST['submit'])){
	 $fullname = $_POST['fullname'];
	 $surname = $_POST['surname'];
	 $snum= $_POST['snum'];
	 $email = $_POST['email'];
	 $phone = $_POST['phone'];
	 $time = $_POST['time'];
	 $device = $_POST['device'];
	 $problem = $_POST['problem'];
	 $Status = 'Open';
	 $sql = "INSERT INTO softwareform VALUES ('$fullname','$surname','$snum', '$email','$phone','$time','$device','$problem','','$Status', ' ', ' ')";
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
	
	
</head>

<body>	
	
<div class = "col-md-6" style='margin-left: 25%' align='left'>
	<div class="well" >
	<p class="lead">
	

<h3 align="center">
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="10%" height="90">
</a>
</h3>



<h1 align='center'  >Thank You For Submiting Your Query</h1>
<h5 align='center' >One of our IT specialists will look into your query and contact you</h5>




<div align ="center">
<div class="d-flex justify-content-center links"> 
Track your Query here!! <a href="homePage.php"> Home</a>
</div>
<div>
<a href="logout.php">Logout <span class="glyphicon glyphicon-off" aria-hidden="true"></span></a>
</div>
</div>		

</div>


</div>
</div>

</div>
<br/>
<br/>
<br/>
<br/>


</div>
</div>
</form>


</body>
</html>