

<?php

include_once 'checkConnection.php';
session_start();
if(isset($_POST['SignIn'])){
	
	$uname = $_POST['Email1'];
	$password = $_POST['password'];
	if(empty($_POST['Email1']) || empty($_POST['Email1']))
	{
		header("location:loginPage.php?Empty= Please Fill in All the Required fields");
	}
	else
	{
		$sql= "select * from login where username= '".$uname."' AND password = '".$password."' limit 1";
		$result = mysqli_query($conn,$sql);
		if(mysqli_fetch_assoc($result))
		{
			$_SESSION['User'] = $uname; 
			header("location:homePage.php");
		}
		else
		{
			header("location:loginPage.php?Invalid= Please Enter the Correct Student number and Password");
			
		}
	}
	
	

}

/*if(isset($_POST['track'])){
	
	$query = "SELECT `FullName`, `Snumber`,`Problem`,  `TicketStatus` FROM `softwareform` WHERE `Snumber`= '201418090'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$results = mysqli_query($conn,$query);

	if(mysqli_num_rows($results) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			
			
			
			
		}
			
	}}else{
			$Snum = " ";
			$status = " ";
			$FullNames1 = " ";
			$Problem = " ";
	
	//mysqli_free_result($result);
	mysqli_close($conn);

	}*/

?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />

    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>

<body style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
 
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="100%" height="40">
</a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  

      <ul class="nav navbar-nav navbar-left" style='margin-left: 1%'>
        <li role="presentation" class="active"><a href="homePage.php">Home</a></li>
		 <li role="presentation"><a></a></li>
        <li role="presentation"><a href="#myModal" data-toggle="modal">Ticket Tracking</a></li>
          <li role="presentation"><a href="aboutus.php">About Us</a></li>
        <li role="presentation"><a href="contactus.php">Contact Us</a></li>
      </ul>
	  
	 
	 
	<ul class="nav navbar-nav navbar-right" style='margin-left: 1%'>
        
		<li role="presentation"><a href="logout.php" name = "logout">LOGOUT <span class="glyphicon glyphicon-off" aria-hidden="true"></span> </a></li>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

</header>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
	  <?php

include_once 'checkConnection.php';  

	$query1 = "SELECT * FROM `softwareform` WHERE `Snumber`= '$uname'";
	$result1 = mysqli_query($conn,$query1);
	if($result1){
		foreach($result1 as $row){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
		}
	}

?>
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" ><img border="0" alt="SMU" src="smu.jpg" width="8%" height="40"> Ticket Status</h4>
        </div>
        <div class="modal-body">
		
           <form>
		     <div class="form-group">
            <label for="recipient-name" class="control-label" name="ss"><h4>Status: <span class="label label-warning"><?php echo $status ?></span></h4> </label>
            
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Reference Number:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $Snum ?>" readonly>
          </div>

          <div class="form-group">
            <label for="message-text" class="control-label">Your Query:</label readonly>
            <textarea class="form-control" id="message-text"> <?php echo $Problem ?></textarea>
          </div>
        </form>
		
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <!--end of the Modal -->
  



 
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">



        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">



<div class = "col-md-12" style='margin-left:30%' align='left'>
	<div class="well" >
	<p class="lead">

<a href="homePage.php" name = "logout"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="30" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
</svg> </a>


              <h2 class="text-uppercase text-center mb-5">ICT Service Request Form</h2>
<hr/>

              <form action = "Thanks.php" method = "post" >

                <div class="form-outline mb-4" >
		  <label class="form-label" for="FullNames">Full Names</label>
                  <input type="text" id="FullNames" name ="fullname" class="form-control form-control-lg" required />
                  
                </div>

                <div class="form-outline mb-4">
                  <label class="form-label" for="Surname">Surname</label>
                  <input type="text" id="Surname" name ="surname" class="form-control form-control-lg" required />
                  
                </div>

                <div class="form-outline mb-4">
                  <label class="form-label" for="StudentNumber">Student/Staff Number</label>
                  <input type="text" id="StudentNumber" name="snum" class="form-control form-control-lg" required />
                  
                </div>


                <div class="form-outline mb-4">
                  <label class="form-label" for="Email">Email Address</label>
                  <input type="email" id="Email" name="email" class="form-control form-control-lg" required />
                  
                </div>

                <div class="form-outline mb-4">
                  <label class="form-label" for="Phone">Mobile Phone Numbers</label>
                  <input type="text" id="Phone" name="phone" class="form-control form-control-lg" required />
                  
                </div>

                <div class="form-outline mb-4">
                  <label class="form-label" for="Date">Estimated Collection Time</label>
                  <input type="text" id="Date" name="time" class="form-control form-control-lg" placeholder="YYYY/MM/DD" />
                  
                </div>


<br/>
                <div class="form-outline mb-4">
                  <label class="form-label" for="Device">Select Device Type:</label

                <!-- Default checked radio -->
                <div class="form-check">
                <input class="form-check-input" type="radio" name="device" value="Laptop" id="Laptop" checked/>
                <label class="form-check-label" for="Laptop"> Laptop </label>
                </div>
                 <div class="form-check">
                 <input class="form-check-input" type="radio" name="device" value="Tablet" id="Tablet"/>
                 <label class="form-check-label" for="Tablet"> Tablet </label>
               </div>
                  
                </div>


                <div class="form-outline mb-4">
                  <label class="form-label" for="Phone">Problem Description:</label>
                  <div class="form-outline">
                  <textarea class="form-control" id="textAreaExample" name="problem" rows="4" required></textarea>
                  
                </div>
                  
                </div>

               
<br/>
                <div class="d-flex justify-content-center">
				
                  <button type="submit" name = "submit" class="btn btn-primary btn-block btn-lg gradient-custom-4 text-body">Submit Request</button>
                  
                </div>


              </form>

</div>

</body>	


		
           

            
