<?php

include_once 'checkConnection.php';
session_start();
if(isset($_POST['SignIn'])){
	
	$uname = $_POST['Email1'];
	$password = $_POST['password'];
	if(empty($_POST['Email1']) || empty($_POST['Email1']))
	{
		header("location:adminLogin.php?Empty= Please Fill in All the Required fields");
	}
	else
	{
		$sql= "select * from admin where username= '".$uname."' AND password = '".$password."' limit 1";
		$result = mysqli_query($conn,$sql);
		if(mysqli_fetch_assoc($result))
		{
			$_SESSION['User'] = $uname; 
			header("location:track1.php");
		}
		else
		{
			header("location:adminLogin.php?Invalid= Please Enter the Correct Student number and Password");
			
		}
	}
	
	

}

/*if(isset($_POST['track'])){
	
	$query = "SELECT `FullName`, `Snumber`,`Problem`,  `TicketStatus` FROM `softwareform` WHERE `Snumber`= '201418090'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$results = mysqli_query($conn,$query);

	if(mysqli_num_rows($results) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
			
			
			
			
		}
			
	}}else{
			$Snum = " ";
			$status = " ";
			$FullNames1 = " ";
			$Problem = " ";
	
	//mysqli_free_result($result);
	mysqli_close($conn);

	}*/

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />

    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>


<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
 
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="100%" height="40">
</a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  

      <ul class="nav navbar-nav navbar-left" style='margin-left: 1%'>
        <li role="presentation" class="active"><a href="track1.php">Home</a></li>

      </ul>
	  
	 
	 
	<ul class="nav navbar-nav navbar-right" style='margin-left: 1%'>
        
		<li role="presentation"><a href="logout.php" name = "logout">LOGOUT <span class="glyphicon glyphicon-off" aria-hidden="true"></span> </a></li>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<!-- Modal -->
 
  
    
      <!-- Modal content-->
	  
<?php

include_once 'checkConnection.php';  

	$query = "SELECT * FROM `softwareform`";// WHERE `Snumber`= '201418090'";
	$result = mysqli_query($conn,$query);
	if($result){
		foreach($result as $row){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
		}
	}
	
				if(isset($_POST['Progress'])){	 
			//$Snum = $row['Snumber'];
			//$status = $_POST['TicketStatus'];
		
	 
	 
                $sql1 = "UPDATE softwareform SET TicketStatus ='In Progress' WHERE Snumber = '201906282'";
           
	  if (mysqli_query($conn, $sql1)) {
		echo " ";
	 } 
	}
	if(isset($_POST['complete'])){	 
			//$Snum = $row['Snumber'];
			//$status = $_POST['TicketStatus'];
		
	
	 
                $sql1 = "UPDATE softwareform SET TicketStatus ='Complete' WHERE Snumber = '201906282'";
           
	  if (mysqli_query($conn, $sql1)) {
		echo " ";
	 } 
	}	
	

?>
	 

<div class="container">

 <form class="navbar-form navbar-right" action="ticketDetails.php" method ="POST">
      <div class="form-group">
        <input type="text" name="reference" class="form-control" placeholder="Search">
      </div>
      <button type="submit" name = "Search" class="btn btn-success">Search Ticket</button>
    </form>

  <h2>Open and In Progress Ticket</h2>
  
  <table class="table">
    <thead>
      <tr  class="info">
        <th>Fullname</th>
        <th>Surname</th>
        <th>Reference Number</th>
        <th>Email</th>
        <th>Phone Numbers</th>
        <th>status</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
       <?php 
	     
			if($result){
		foreach($result as $row)
	     {
			 
			 ?>
			 
	   
	    <tr>
        <td><?php echo $row['FullName'];  ?></td>      
        <td><?php echo $row['Surname'];  ?></td>
        <td><?php echo $row['Snumber'];  ?></td>
        <td><?php echo $row['Email'];  ?></td>
        <td><?php echo $row['Mobile'];  ?></td>
        <td><?php echo $row['TicketStatus']; ?></td>
        <td></td>
      </tr> 

  
	  
	  <?php
			 }
			}
	  
	  
	  ?>     
       <tr class="active">
        
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td></td>
      </tr>
    </tbody>
  </table>
</div>



<div class="container">

  <div>
 
  <h2>Download Reports</h2>
 

   </div>
 <form action = "download.php" method = "post">
  <table class="table">
    <thead>
      <tr  class="info">
        <th><span class="label label-default modal-lg">Open</span></th>
        <th><span class="label label-warning modal-lg">In Progress</span></th>
        <th><span class="label label-success modal-lg">Competed</span></th>
        <th><span class="label label-primary modal-lg">All Statuses</span></th>
      </tr 
		
			
      
      </tr>
      <tr class="active">
        <td> <button type="submit" name = "download" class="btn btn-success">Download</button></td>
        <td><button type="submit" name = "download1" class="btn btn-success gradient-custom-4 text-body">Download</button></td>
        <td><button type="submit" name = "download2" class="btn btn-success gradient-custom-4 text-body">Download</button></td>
        <td><button type="submit" name = "download3" class="btn btn-success gradient-custom-4 text-body">Download</button></td>
      </tr>      
 
	  
    
	 
	  
    </thead>

  </table>
</div>
</form>


</body>
	


</html>