<?php
include_once 'checkConnection.php';
session_start();
if(isset($_POST['submit'])){
	 $fullname = $_POST['fullname'];
	 $surname = $_POST['surname'];
	 $snum= $_POST['snum'];
	 $email = $_POST['email'];
	 $phone = $_POST['phone'];
	 
	 $Status = 'Open';
	 $sql = "INSERT INTO softwareform VALUES ('$fullname','$surname','$snum', '$email','$phone',' ',' ',' ','','$Status', ' ', ' ')";
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />

    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>

<body style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
 
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="100%" height="40">
</a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  

      <ul class="nav navbar-nav navbar-left" style='margin-left: 1%'>
        <li role="presentation" class="active"><a href="homePage.php">Home</a></li>
		 <li role="presentation"><a></a></li>
        <li role="presentation"><a href="#myModal" data-toggle="modal">Ticket Tracking</a></li>
        <li role="presentation"><a href="aboutus.php">About Us</a></li>
        <li role="presentation"><a href="contactus.php">Contact Us</a></li>
		
      </ul>
	  
	 
	 
	<ul class="nav navbar-nav navbar-right" style='margin-left: 1%'>
        
		<li role="presentation"><a href="logout.php" name = "logout">LOGOUT <span class="glyphicon glyphicon-off" aria-hidden="true"></span> </a></li>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

</header>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
	  <?php

include_once 'checkConnection.php';  

	$query1 = "SELECT * FROM `softwareform` WHERE `Snumber`= '201418090'";
	$result1 = mysqli_query($conn,$query1);
	if($result1){
		foreach($result1 as $row){
			$Snum = $row['Snumber'];
			$status = $row['TicketStatus'];
			$FullNames1 = $row['FullName'];
			$Problem = $row['Problem'];
		}
	}

?>
       <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" ><img border="0" alt="SMU" src="smu.jpg" width="8%" height="40"> Ticket Status</h4>
        </div>
        <div class="modal-body">
		
           <form>
		     <div class="form-group">
            <label for="recipient-name" class="control-label" name="ss"><h4>Status: <span class="label label-warning"><?php echo $status ?></span></h4> </label>
            
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Reference Number:</label>
            <input type="text" class="form-control" name="TicketStatus" id="recipient-name"  value="<?php echo $Snum ?>" readonly>
          </div>

          <div class="form-group">
            <label for="message-text" class="control-label">Your Query:</label readonly>
            <textarea class="form-control" id="message-text"> <?php echo $Problem ?></textarea>
          </div>
        </form>
		
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  <!--end of the Modal -->

<body>	
	
<div class = "col-md-6" style='margin-left: 25%' align='left'>
	<div class="well" >
	<p class="lead">
	

<h3 align="left">
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu.jpg" width="10%" height="90">
</a>
</h3>



<h3 align='left'  >Physical Address:</h3>
<p>
Molotlegi Street <br/>
Ga-Rankuwa, Pretoria,<br/>
Gauteng<br/>

<h3 align='left'  >Postal Address:</h3>
Registry<br/>
P.O Box 60<br/>
Medunsa, 0204<br/>

<br/>
<br/>
<h3 align='left'  >PHYSICAL ADDRESS:</h3>
ICT Building<br/>
(Next to Production Unit)<br/>

Tel: (012) 521 3376




 </p>





		

</div>


</div>
</div>

</div>
<br/>
<br/>
<br/>
<br/>


</div>
</div>
</form>


</body>
</html>