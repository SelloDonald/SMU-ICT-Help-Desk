<?php 
require_once 'FPDF/fpdf.php';
include_once 'checkConnection.php';
$query = "SELECT * FROM `softwareform`";// WHERE `Snumber`= '201418090'";
$queryOpen = "SELECT * FROM `softwareform` WHERE `TicketStatus`= 'Open'";
$queryProgress = "SELECT * FROM `softwareform` WHERE `TicketStatus`= 'In Progress'";
$queryComp = "SELECT * FROM `softwareform` WHERE `TicketStatus`= 'Complete'";

$result = mysqli_query($conn,$query);
$result2 = mysqli_query($conn,$queryOpen);
$result3 = mysqli_query($conn,$queryProgress);
$result4 = mysqli_query($conn,$queryComp);



if(isset($_POST['download3'])){

	$pdf = new FPDF('p','mm', 'a3');
	$pdf -> SetFont('arial','b','14');
	$pdf -> AddPage();
	$pdf -> cell('40','10','Full Name','1','0','C');
	$pdf -> cell('40', '10', 'Surname','1','0','C');
	$pdf -> cell('40', '10', 'Reference','1','0','C');
	$pdf -> cell('60', '10', 'Email','1','0','C');
	$pdf -> cell('40', '10', 'Phone Numbers','1','0','C');
	$pdf -> cell('40', '10', 'Status','1','1','C');
	
	$pdf -> SetFont('arial','','12');
	while($row = mysqli_fetch_assoc($result))
	{
	$pdf -> cell('40','10', $row['FullName'],'1','0','C');
	$pdf -> cell('40', '10', $row['Surname'],'1','0','C');
	$pdf -> cell('40', '10', $row['Snumber'],'1','0','C');
	$pdf -> cell('60', '10', $row['Email'],'1','0','C');
	$pdf -> cell('40', '10', $row['Mobile'],'1','0','C');
	$pdf -> cell('40', '10', $row['TicketStatus'],'1','1','C');
		
	}
	
	$pdf -> Output();
	



}
if(isset($_POST['download'])){
		
	$pdf = new FPDF('p','mm', 'a3');
	$pdf -> SetFont('arial','b','14');
	$pdf -> AddPage();
	$pdf -> cell('40','10','Full Name','1','0','C');
	$pdf -> cell('40', '10', 'Surname','1','0','C');
	$pdf -> cell('40', '10', 'Reference','1','0','C');
	$pdf -> cell('60', '10', 'Email','1','0','C');
	$pdf -> cell('40', '10', 'Phone Numbers','1','0','C');
	$pdf -> cell('40', '10', 'Status','1','1','C');
	
	$pdf -> SetFont('arial','','12');
	while($row = mysqli_fetch_assoc($result2))
	{
	$pdf -> cell('40','10', $row['FullName'],'1','0','C');
	$pdf -> cell('40', '10', $row['Surname'],'1','0','C');
	$pdf -> cell('40', '10', $row['Snumber'],'1','0','C');
	$pdf -> cell('60', '10', $row['Email'],'1','0','C');
	$pdf -> cell('40', '10', $row['Mobile'],'1','0','C');
	$pdf -> cell('40', '10', $row['TicketStatus'],'1','1','C');
		
	}
	
	$pdf -> Output();
	}
if(isset($_POST['download1'])){
		
		
	$pdf = new FPDF('p','mm', 'a3');
	$pdf -> SetFont('arial','b','14');
	$pdf -> AddPage();
	$pdf -> cell('40','10','Full Name','1','0','C');
	$pdf -> cell('40', '10', 'Surname','1','0','C');
	$pdf -> cell('40', '10', 'Reference','1','0','C');
	$pdf -> cell('60', '10', 'Email','1','0','C');
	$pdf -> cell('40', '10', 'Phone Numbers','1','0','C');
	$pdf -> cell('40', '10', 'Status','1','1','C');
	
	$pdf -> SetFont('arial','','12');
	while($row = mysqli_fetch_assoc($result3))
	{
	$pdf -> cell('40','10', $row['FullName'],'1','0','C');
	$pdf -> cell('40', '10', $row['Surname'],'1','0','C');
	$pdf -> cell('40', '10', $row['Snumber'],'1','0','C');
	$pdf -> cell('60', '10', $row['Email'],'1','0','C');
	$pdf -> cell('40', '10', $row['Mobile'],'1','0','C');
	$pdf -> cell('40', '10', $row['TicketStatus'],'1','1','C');
		
	}
	
	$pdf -> Output();
	}
		
if(isset($_POST['download2'])){
		
		
	$pdf = new FPDF('p','mm', 'a3');
	$pdf -> SetFont('arial','b','14');
	$pdf -> AddPage();
	$pdf -> cell('40','10','Full Name','1','0','C');
	$pdf -> cell('40', '10', 'Surname','1','0','C');
	$pdf -> cell('40', '10', 'Reference','1','0','C');
	$pdf -> cell('60', '10', 'Email','1','0','C');
	$pdf -> cell('40', '10', 'Phone Numbers','1','0','C');
	$pdf -> cell('40', '10', 'Status','1','1','C');
	
	$pdf -> SetFont('arial','','12');
	while($row = mysqli_fetch_assoc($result4))
	{
	$pdf -> cell('40','10', $row['FullName'],'1','0','C');
	$pdf -> cell('40', '10', $row['Surname'],'1','0','C');
	$pdf -> cell('40', '10', $row['Snumber'],'1','0','C');
	$pdf -> cell('60', '10', $row['Email'],'1','0','C');
	$pdf -> cell('40', '10', $row['Mobile'],'1','0','C');
	$pdf -> cell('40', '10', $row['TicketStatus'],'1','1','C');
		
	}
	
	$pdf -> Output();
	}



?>