





<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>SMU IT Help Desk</title>
	<link rel="smu icon" href="smu.jpg" />
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap/css/black-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">
	
	
</head>

<body style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">	
	
<div class = "col-md-3" style='margin-left: 35%' align='left'>
	<div class="well" >
	<p class="lead">
	
<h3 align="center">
<a href="https://www.smu.ac.za/">
<img border="0" alt="SMU" src="smu2.jpg" width="100%" height="200">
</a>
</h3>


<?php
if(@$_GET['Empty']==true)
{

?>
    <div class="alert alert-danger text-center py-3" role="alert"><?php echo $_GET['Empty']; ?></div>
<?php
}
?>

<?php //##########################3 ?>

<?php
if(@$_GET['Invalid']==true)
{

?>
    <div class="alert alert-danger text-center py-3" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Incorrect!</strong><?php echo $_GET['Invalid']; ?></div>
<?php
}
?>


<form action = "track1.php" method = "post">

    <div class="form-group">
	<label for="Email"> Student/Staff Number</label>
		<input class="form-control" type = "text" name = "Email1" placeholder="Student or Staff Number" >
<br/>


		<label for="Names"> Password</label>
		<input class="form-control" type = "text" name = "password" placeholder="Password" > 
		

		</div>
<br/>

<div align ="center">
<input type = "submit" name = "SignIn" value = "LOGIN" class="btn btn-lg btn-primary">
</div>

</form>
<hr/>

<div align ="center">
<div class="d-flex justify-content-center links"> 
Don't have an account?<a href="index2.html"> Sign Up</a>
</div>
<div>
<a href="#">Forgot your password?</a>
</div>
</div>		

</div>


</div>
</div>

</div>
<br/>
<br/>
<br/>
<br/>


</div>
</div>
</form>


</body>
</html>