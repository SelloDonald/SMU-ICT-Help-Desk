<?php
include_once 'checkConnection.php';  

			/*if(isset($_POST['save'])){	 
			//$Snum = $row['Snumber'];
			//$status = $_POST['TicketStatus'];
		
	  $status = $_POST['status'];
	 
                $sql1 = "UPDATE softwareform SET TicketStatus ='In Progress' WHERE Snumber = '201801173'";
           
	  if (mysqli_query($conn, $sql1)) {
		echo "updated ";
	 } 
	}
	if(isset($_POST['save'])){	 
			//$Snum = $row['Snumber'];
			//$status = $_POST['TicketStatus'];
		 $status = $_POST['status'];
	 
	 
         $sql1 = "UPDATE softwareform SET TicketStatus ='$status' WHERE Snumber = '201801173'";
           
	  if (mysqli_query($conn, $sql1)) {
		echo " updated";
	 } 
	}	*/



	 $assistant = $_POST['assistant'];
	 $problem = $_POST['problems'];
	 $status = $_POST['status'];
	// $sql = "INSERT INTO softwareform VALUES ('','','', '$email','$phone','$time','$device','$problem','','$Status')";
	 
	 	  if(empty($assistant)){
                $sql = "UPDATE softwareform SET Assistant_Name ='$assistant' WHERE Snumber = '201418090'";
            } else if (empty($problem)){
                $sql = "UPDATE softwareform SET Assistant_Name ='$problem' WHERE Snumber = '201418090'";
				}else if(!empty($status)){
					$sql = "UPDATE softwareform SET Assistant_Name ='$status ' WHERE Snumber = '201418090'";
				}
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
	 
	 

?>